//
//  TabBarController.swift
//  GR
//
//  Created by 中森えみり on 2021/04/06.
//

import UIKit


class TabBarController: UITabBarController {
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        }


    

}
