//
//  Constants.swift
//  GR
//
//  Created by 中森えみり on 2021/04/07.
//

import Foundation

struct Constants{
    
    static let titleArray = ["Trend","Search","Nice","Mypage"]
    static let menuArray = ["PS5","PS4","Switch"]
    static let detailMenuArray = ["詳細", "スコア・レビュー"]
    
}
